<?php

namespace Medma\MarketPlace\Block\Product;

use Magento\Catalog\Block\Product\AbstractProduct;

class Report extends AbstractProduct
{


}
