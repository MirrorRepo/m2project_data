<?php
/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Medma\MarketPlace\Controller\Result;

class Index extends \Magento\CatalogSearch\Controller\Result\Index
{
    public function execute($coreRoute = null)
    {
        return parent::execute($coreRoute);
    }
}
