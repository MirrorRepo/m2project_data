var config = {
    "map": {
        '*': {
            'bootstrap.min': 'Medma_MarketPlace/js/bootstrap.min',
            'bootstrapvalidator': 'Medma_MarketPlace/js/bootstrapvalidator',
            'jquery.form':'Medma_MarketPlace/js/jquery.form'
        }
    }
};
