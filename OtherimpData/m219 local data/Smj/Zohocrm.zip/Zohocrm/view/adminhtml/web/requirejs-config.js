/**
 * Copyright © 2015 Smj. All rights reserved.
 * See COPYING.txt for license details.
 *
 * Smj_Zohocrm extension
 * NOTICE OF LICENSE
 *
 * @category Smj
 * @package  Smj_Zohocrm
 * @author   Mukund
 */
var config = {
    map: {
        '*': {
            getZohoCRMAuthKey: 'Smj_Zohocrm/system/get_auth_key'
        }
    }
};