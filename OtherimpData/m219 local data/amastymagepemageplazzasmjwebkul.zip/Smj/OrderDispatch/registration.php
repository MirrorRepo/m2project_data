<?php
/**
 * Smj Software.
 *
 * @category  Smk
 * @package   Smj_OrderDispatch
 * @author    Smk Kush
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Smj_OrderDispatch',
    __DIR__
);
