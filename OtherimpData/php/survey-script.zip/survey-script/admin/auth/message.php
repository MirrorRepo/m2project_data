
<div class='form' style='margin:25px;border:1px solid #ddd;padding:10px;'>
<h4>HIOX DB Installation Manager</h4>
<p>
Your Database Parameters are updated.<br>
To procede to the next step on installation, click Next.</p>
<form name=setf method=POST action='<?php echo $PHP_SELF;?>' >
<input name="type" type=hidden value="createtables">
<input type=submit value="Next" class='form_button' style='float:left;'><div style='clear:both;'></div>
</form>
</div>