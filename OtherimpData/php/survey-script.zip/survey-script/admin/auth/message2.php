<div class='form' style='margin:25px;border:1px solid #ddd;padding:10px;'>
<h4>HIOX DB Installation Manager</h4>
<p>
You have succesfully installed the product.<br>
Do proceed to work with the product.<br>
<br>
This utility is provided by HIOX INDIA.<br>
For more details log on to <a href="https://www.hscripts.com">hscripts.com</a>
</p>
</div>