</div>
<!-- content ends -->

<!-- content ends -->
<div class="footer">&copy; Copyright <?php echo date('Y');?>  by <a href="http://www.hscripts.com">Hscripts.com</a></div>
</body>
</html>
