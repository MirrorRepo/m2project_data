<?php
$hm = "/opt/lampp/htdocs/hscripts-new/responsive/scripts/php/survey-script/admin";
$hm2 = "http://192.168.0.53/hscripts-new/responsive/scripts/php/survey-script/admin";
include "$hm/index.php";
?>