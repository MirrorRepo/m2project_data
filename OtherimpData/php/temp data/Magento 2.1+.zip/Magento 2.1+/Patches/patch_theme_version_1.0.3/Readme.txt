VERSION 1.0.3:
- Fix issue when install theme and import homepage from admin 

If you are using old version and want to update from version 1.0.2 to version 1.0.3, please follow our steps:
- upload app folder to your magento root folder
- go to admin > MGS > [MGS Theme] Theme Setting and "Save Config" again.

If you are new. Please ignore this patch.