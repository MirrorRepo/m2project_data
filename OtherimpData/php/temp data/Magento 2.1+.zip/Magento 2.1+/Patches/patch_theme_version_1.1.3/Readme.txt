VERSION 1.1.3:
- Support for Mageplaza Onestep Checkout extension

If you are using version 1.1.2 and want to update to version 1.1.3, please follow our steps:
- upload app folder to your magento root folder
- remove var/*
- remove pub/static/frontend/Mgs
- run deploy command: php bin/magento setup:static-content:deploy

If you are new. Please ignore this patch.