VERSION 1.1.6:
- Fix instagram feed issue

If you are new please ignore this patch.

- remove var/*
- remove pub/static/frontend/Mgs
- run deploy command: php bin/magento setup:static-content:deploy -f