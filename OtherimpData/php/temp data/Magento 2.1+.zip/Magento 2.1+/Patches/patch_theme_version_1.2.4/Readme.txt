VERSION 1.2.4:
- Update multiple filter for color

If you are new, please ignore this patch.
Please follow our steps to update:
- upload app folder to your magento root folder