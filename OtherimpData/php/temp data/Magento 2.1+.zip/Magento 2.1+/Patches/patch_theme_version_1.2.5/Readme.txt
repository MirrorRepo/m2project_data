VERSION 1.2.5:
- Update dark version

If you are new, please ignore this patch.
Please follow our steps to update:
- upload 2 folders app and pub to your magento root folder
- remove generated/code
- remove var/*
- remove pub/static/frontend/Mgs
- run deploy command: php bin/magento setup:static-content:deploy -f