<strong>Product Tabs</strong> extension for Magento allow admin to manage tabs of products.

Default of magento v2.0, in product details page showing 3 tabs are: Details, More Information and Reviews. With this extension admin can add unlimited tabs. The tab can be use static blocks or attributes.

<h2>Features List:</h2>
<ul>
<li>Add tab use attribute</li>
<li>Add tab use static block</li>
<li>Enable "Review" tab</li>
<li>Enable "More Information" tab</li>
<li>Change title of tabs</li>
<li>Change position of tabs</li>
<li>Easy to manage</li>
<li>Easy to use</li>
</ul>