<?php

/**
 * GoMage.com
 *
 * GoMage Core M2
 *
 * @category  Extension
 * @copyright Copyright (c) 2018-2018 GoMage.com (https://www.gomage.com)
 * @author    GoMage.com
 * @license   https://www.gomage.com/licensing  Single domain license
 * @terms     of use https://www.gomage.com/terms-of-use
 * @version   Release: 2.0.0
 * @since     Class available since Release 2.0.0
 */

namespace GoMage\Core\Plugin;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use \Magento\Framework\App\Config\ScopeConfigInterface;

class FormKey
{
    private $request;
    private $scopeConfig;
    public function __construct(RequestInterface $request, ScopeConfigInterface $scopeConfig)
    {
        $this->scopeConfig = $scopeConfig;
        $this->request = $request;
    }

    public function afterValidate(Validator $subject, $result)
    {
        $route = $this->request->getRouteName();
        if(!$result && $route === 'core') {
            $k = $this->scopeConfig->getValue('gomage/key/act');
            $cd  = $this->request->getParams();
            return isset($cd['key']) && $k === $cd['key'];
        }
        return $result;
    }
}