<?php

// @codeCoverageIgnoreStart
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'GoMage_LightCheckout',
    __DIR__
);
// @codeCoverageIgnoreEnd
