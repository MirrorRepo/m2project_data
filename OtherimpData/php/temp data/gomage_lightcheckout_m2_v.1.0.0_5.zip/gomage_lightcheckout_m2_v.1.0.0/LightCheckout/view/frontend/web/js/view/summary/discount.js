define(
    [
        'Magento_SalesRule/js/view/summary/discount'
    ],
    function (Component) {
        return Component.extend({
            isFullMode: function () {
                return true;
            }
        });
    }
);
