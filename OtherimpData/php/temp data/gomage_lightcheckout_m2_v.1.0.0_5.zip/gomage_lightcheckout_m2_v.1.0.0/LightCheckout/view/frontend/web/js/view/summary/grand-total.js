define(
    [
        'Magento_Tax/js/view/checkout/summary/grand-total'
    ],
    function (Component) {
        "use strict";
        return Component.extend({
            isDisplayed: function () {
                return true;
            }
        });
    }
);
