<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2019 Amasty (https://www.amasty.com)
 * @package Amasty_GiftCard
 */


namespace Amasty\GiftCard\Model;

/**
 *  Need to rewrite Magento\SalesRule\Model\Rule class used in di.xml for rewrite only our code pool conditions
 */
class Rule extends \Magento\SalesRule\Model\Rule
{
}
