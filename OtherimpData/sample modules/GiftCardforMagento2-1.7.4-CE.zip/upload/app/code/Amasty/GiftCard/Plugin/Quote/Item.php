<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2019 Amasty (https://www.amasty.com)
 * @package Amasty_GiftCard
 */


namespace Amasty\GiftCard\Plugin\Quote;

use Amasty\Base\Model\Serializer;
use Amasty\GiftCard\Model\GiftCard;
use Amasty\GiftCard\Model\Product\Type\GiftCard as GiftCardType;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Pricing\PriceCurrencyInterface;

class Item
{
    private $price = [];

    private $basePrice = [];

    /**
     * @var Serializer
     */
    private $serializer;

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var PriceCurrencyInterface
     */
    private $priceCurrency;

    public function __construct(
        Serializer $serializer,
        ProductRepositoryInterface $productRepository,
        PriceCurrencyInterface $priceCurrency
    ) {
        $this->serializer = $serializer;
        $this->productRepository = $productRepository;
        $this->priceCurrency = $priceCurrency;
    }

    /**
     * @param \Magento\Quote\Model\Quote\Item $item
     * @param $price
     * @return float
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function afterGetConvertedPrice(
        \Magento\Quote\Model\Quote\Item $item,
        $price
    ) {
        $product = $item->getProduct();

        if ($item->getBasePrice()) {
            return $this->priceCurrency->convertAndRound($item->getBasePrice());
        }

        if ($product->getTypeId() == GiftCardType::TYPE_GIFTCARD_PRODUCT) {
            $itemId = $item->getId();
            if (isset($this->price[$itemId])) {
                return $this->price[$itemId];
            }
            if (isset($item->getOptionsByCode()['info_buyRequest']['value'])) {
                $options = $this->serializer->unserialize($item->getOptionsByCode()['info_buyRequest']['value']);
                $price = $this->getResultPrice($options, $product, $item->getQuote()->getBaseToQuoteRate());
                $this->price += [$itemId => $price];
            }
        }

        return $price;
    }

    /**
     * @param \Magento\Quote\Model\Quote\Item $item
     * @param $price
     *
     * @return float
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function afterGetBaseCalculationPriceOriginal(
        \Magento\Quote\Model\Quote\Item $item,
        $price
    ) {
        $product = $item->getProduct();

        if ($product->getTypeId() == GiftCardType::TYPE_GIFTCARD_PRODUCT) {
            $itemId = $item->getId();

            if (isset($this->basePrice[$itemId])) {
                return $this->basePrice[$itemId];
            }

            if (isset($item->getOptionsByCode()['info_buyRequest']['value'])) {
                if (!($price = $item->getBasePrice())) {
                    $rate = $item->getQuote()->getBaseToQuoteRate() ?:
                        $this->priceCurrency->convertAndRound(100) / 100;

                    $options = $this->serializer->unserialize($item->getOptionsByCode()['info_buyRequest']['value']);
                    $price = $this->getPriceByOption($options) / $rate;
                    $price = $this->getPriceByFee($product, $price, 1);
                    $product->setBasePrice($price);
                }

                $this->basePrice += [$itemId => $price];
            }
        }

        return $price;
    }

    /**
     * @param $options
     * @param \Magento\Catalog\Api\Data\ProductInterface $product
     * @param float $baseRate
     *
     * @return float
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    private function getResultPrice($options, $product, $baseRate)
    {
        $price = $this->getPriceByOption($options);
        $resultPrice = $this->getPriceByFee($product, $price, $baseRate);

        return $resultPrice;
    }

    /**
     * @param $options
     * @return int|mixed
     */
    private function getPriceByOption($options)
    {
        if (isset($options['am_giftcard_amount_custom']) && $options['am_giftcard_amount_custom']) {
            $price = $options['am_giftcard_amount_custom'];
        } else {
            $price = isset($options['am_giftcard_amount']) ? $options['am_giftcard_amount'] : null;
        }

        return $price;
    }

    /**
     * @param \Magento\Catalog\Api\Data\ProductInterface $product
     * @param $price
     * @param float $baseRate
     *
     * @return float
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    private function getPriceByFee($product, $price, $baseRate)
    {
        if (!$price) {
            return $price;
        }

        $feeEnabled = $product->getAmGiftcardFeeEnable();
        $feeType = $product->getAmGiftcardFeeType();

        /*missing gift card products options on checkout cart*/
        if ($feeEnabled == null || $feeType == null) {
            $product = $this->productRepository->getById($product->getId());
            $feeEnabled = $product->getAmGiftcardFeeEnable();
            $feeType = $product->getAmGiftcardFeeType();
        }

        if (!$feeEnabled) {
            return $price;
        }

        $feeValue = (float)$product->getAmGiftcardFeeValue();
        $adj = 0;

        if ($feeType == GiftCard::PRICE_TYPE_PERCENT) {
            $adj = $price * $feeValue / 100;
        } elseif ($feeType == GiftCard::PRICE_TYPE_FIXED) {
            $adj = $feeValue * $baseRate;
        }

        $price += $adj;

        return $price;
    }
}
