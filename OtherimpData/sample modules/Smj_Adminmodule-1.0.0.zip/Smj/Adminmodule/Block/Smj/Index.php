<?php
/**
 * Copyright © 2015 Smj . All rights reserved.
 */
namespace Smj\Adminmodule\Block\Smj;
use Smj\Adminmodule\Block\BaseBlock;
class Index extends BaseBlock
{
	public $hello='Hello World';
	
}
