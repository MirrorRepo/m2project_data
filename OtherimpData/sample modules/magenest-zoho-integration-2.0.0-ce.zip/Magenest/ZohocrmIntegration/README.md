# README
Thank you for buying our product.
This extension adheres to [Magenest](https://store.magenest.com/).

### User guide
- If you have trouble installing this extension, please visit: http://www.confluence.izysync.com/display/DOC/1.+Zoho+CRM+Integration+Installation+Guides

- For detailed user guide of this extension, please visit: http://www.confluence.izysync.com/display/DOC/2.+Zoho+CRM+Integration+User+Guides

- Support portal: http://servicedesk.izysync.com/servicedesk/customer/portal/27

- All the updates of this module are included in CHANGELOG.md file.