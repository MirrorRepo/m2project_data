<?php
/**
 * Bakeway
 *
 * @category  Bakeway
 * @package   Bakeway_Uc
 * @author    Bakeway
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Bakeway_Uc',
    __DIR__
);
